-- 1) Retrieve the total no.of orders placed

SELECT 
    COUNT(Order_Id) AS Total_Orders
FROM
    Orders; 

-- 2) Calculate the total revenue generated from pizza sales.

SELECT 
    ROUND(SUM(order_details.Quantity * pizzas.price),
            2) AS Total_Sales
FROM
    order_details
        JOIN
    pizzas ON pizzas.pizza_id = order_details.Pizza_Id;
    
 -- 3)Identify the highest-priced pizza
 
SELECT 
    pizza_types.name, pizzas.price
FROM
    pizza_types
        JOIN
    pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
ORDER BY pizzas.price DESC
LIMIT 1;
    
-- 4) Identify the most common pizza size ordered

SELECT 
    pizzas.size AS Most_Ordered_Size,
    COUNT(order_details.Order_Details_Id) AS Order_Count
FROM
    pizzas
        JOIN
    order_details ON pizzas.pizza_id = order_details.Pizza_Id
GROUP BY pizzas.size
ORDER BY Order_Count DESC
LIMIT 1;

-- 5) List the top 5 most ordered pizza types along with their quantities.

SELECT 
    pizza_types.name AS Pizza_Names,
    SUM(order_details.Quantity) AS Total_Quantity
FROM
    pizza_types
        JOIN
    pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
        JOIN
    order_details ON order_details.Pizza_Id = pizzas.pizza_id
GROUP BY Pizza_Names
ORDER BY Total_Quantity DESC
LIMIT 5;









    
    
    
    
    
    
    