-- 1) Join the necessary tables to find the total quantity of each pizza category ordered.

SELECT 
    pizza_types.category,
    SUM(order_details.Quantity) AS Total_Quantity
FROM
    pizza_types
        JOIN
    pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
        JOIN
    order_details ON order_details.Pizza_Id = pizzas.pizza_id
GROUP BY pizza_types.category
ORDER BY Total_Quantity desc;

-- 2) Determine the distribution of orders by hour of the day.

SELECT 
    HOUR(Order_Time) AS Hours, COUNT(Order_Id) AS Order_Count
FROM
    orders
GROUP BY Hours
ORDER BY Order_Count;

-- 3) Join relevant tables to find the category-wise distribution of pizzas.

SELECT 
    category, COUNT(name) as Pizza_Count
FROM
    pizza_types
GROUP BY category;

-- 4) Group the orders by date and calculate the average number of pizzas ordered per day.

SELECT 
    AVG(Total_Quantity)
FROM
    (SELECT 
        orders.Order_Date,
            SUM(order_details.Quantity) AS Total_Quantity
    FROM
        orders
    JOIN order_details ON orders.Order_Id = order_details.Order_Id
    GROUP BY orders.Order_Date) AS Order_Quantity;
    
    -- 5) Determine the top 3 most ordered pizza types based on revenue.
    
    select pizza_types.name, sum(order_details.quantity * pizzas.price) as Revenue
    from pizza_types join pizzas
    on pizza_types.pizza_type_id = pizzas.pizza_type_id
    join order_details
    on order_details.Pizza_Id = pizzas.pizza_id
    group by pizza_types.name order by Revenue Desc limit 3;
































